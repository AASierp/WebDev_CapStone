import { Link } from "react-router-dom"

function NavBar(){
    return 
    <nav className = "navbar">
        <div>
            
        </div>
    </nav>
}